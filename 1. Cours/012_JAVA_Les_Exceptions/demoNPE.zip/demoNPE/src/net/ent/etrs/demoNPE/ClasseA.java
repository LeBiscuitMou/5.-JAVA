package net.ent.etrs.demoNPE;

public class ClasseA {

    private String nom;

    public ClasseA(String nom) {
        setNom(nom);
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
