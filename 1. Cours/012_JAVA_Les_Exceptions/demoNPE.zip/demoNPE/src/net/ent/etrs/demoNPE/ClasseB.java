package net.ent.etrs.demoNPE;

public class ClasseB {

    ClasseA cA;

    public ClasseA getcA() {
        return cA;
    }

    public void setcA(ClasseA cA) {
        this.cA = cA;
    }
}
