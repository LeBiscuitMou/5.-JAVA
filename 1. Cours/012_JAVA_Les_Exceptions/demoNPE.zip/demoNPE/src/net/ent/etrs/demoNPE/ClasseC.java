package net.ent.etrs.demoNPE;

public class ClasseC {

    ClasseB cB;

    public ClasseC(ClasseB cB) {
        setcB(cB);
    }

    public ClasseB getcB() {
        return cB;
    }

    public void setcB(ClasseB cB) {
        this.cB = cB;
    }
}
