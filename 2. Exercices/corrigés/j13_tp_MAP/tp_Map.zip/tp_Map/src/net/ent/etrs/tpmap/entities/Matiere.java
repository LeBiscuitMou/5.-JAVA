package net.ent.etrs.tpmap.entities;

public enum Matiere {
    HTML,
    SQL,
    COO,
    JAVA,
    ANASI,
    BDD,
    PROJET
}
