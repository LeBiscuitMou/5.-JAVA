package net.ent.etrs.coffrefort.model.refs;

public enum Etat {
    OPEN,
    CLOSE
}
