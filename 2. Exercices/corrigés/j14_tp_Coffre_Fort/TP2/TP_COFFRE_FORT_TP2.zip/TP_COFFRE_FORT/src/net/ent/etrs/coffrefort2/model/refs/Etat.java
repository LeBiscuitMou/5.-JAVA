package net.ent.etrs.coffrefort2.model.refs;

public enum Etat {
    OPEN,
    CLOSE
}
