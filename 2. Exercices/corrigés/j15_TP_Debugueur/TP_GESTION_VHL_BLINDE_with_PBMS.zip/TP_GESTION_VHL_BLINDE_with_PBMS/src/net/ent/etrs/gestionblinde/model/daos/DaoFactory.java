package net.ent.etrs.gestionblinde.model.daos;

public class DaoFactory {
}
