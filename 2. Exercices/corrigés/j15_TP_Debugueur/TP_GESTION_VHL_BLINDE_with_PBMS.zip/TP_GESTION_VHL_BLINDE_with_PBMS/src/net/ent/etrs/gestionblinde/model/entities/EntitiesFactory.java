package net.ent.etrs.gestionblinde.model.entities;

import net.ent.etrs.gestionblinde.model.entities.exceptions.VehiculeBlindeMetierException;

import java.util.UUID;

public final class EntitiesFactory {
    private EntitiesFactory() {
    }

    public VehiculeBlinde fabriquerCharAssaut(String emat8, Integer poids){
        try {
            return new CharAssault(emat8,poids);
        } catch (VehiculeBlindeMetierException e) {
            throw new RuntimeException(e);
        }
    }

    public VehiculeBlinde fabriquerVhlTransportTroupes(String emat8, Integer poids){
        try {
            return new VehiculeTransportTroupes(emat8,poids);
        } catch (VehiculeBlindeMetierException e) {
            throw new RuntimeException(e);
        }
    }


}
