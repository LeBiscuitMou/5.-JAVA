package net.ent.etrs.gestionblinde.model.entities;

public class Obus120 extends Obus{

    public Obus120(String nom, Integer poids, Integer masseExplosive) {
        super(nom, poids, masseExplosive);
    }
}
