package net.ent.etrs.gestionblinde.model.entities;

public class Obus25 extends Obus{
    protected Obus25(String nom, Integer poids, Integer masseExplosive) {
        super(nom, poids, masseExplosive);
    }
}
