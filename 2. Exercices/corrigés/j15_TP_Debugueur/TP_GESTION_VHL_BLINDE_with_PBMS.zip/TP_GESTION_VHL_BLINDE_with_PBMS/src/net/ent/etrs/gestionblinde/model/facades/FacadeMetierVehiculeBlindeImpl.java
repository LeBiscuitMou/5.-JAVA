package net.ent.etrs.gestionblinde.model.facades;

import net.ent.etrs.gestionblinde.model.entities.VehiculeBlinde;

import java.util.List;
import java.util.UUID;

public class FacadeMetierVehiculeBlindeImpl implements FacadeMetierVehiculeBlinde {
    @Override
    public VehiculeBlinde ajouterVehiculeBlinde(VehiculeBlinde vhl) {
        return null;
    }

    @Override
    public VehiculeBlinde majVehiculeBlinde(VehiculeBlinde vhl) {
        return null;
    }

    @Override
    public List<VehiculeBlinde> selectionnerTousVehiculeBlinde() {
        return null;
    }

    @Override
    public void supprimerVehiculeBlinde(UUID emmat8) {

    }
}
