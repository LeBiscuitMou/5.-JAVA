package net.ent.etrs.exo2;

import net.ent.etrs.exo2.model.entities.Ville;

public class Lanceur {
    public static void main(String[] args) {

        //Création d'une instance de ville
        Ville uneVille = new Ville();

        //Affectation de valeurs
        uneVille.nom = "Rennes";
        uneVille.nbHabitant = 215_000;

        //Afficher les informations de la ville

        uneVille.afficherInfo();



    }
}