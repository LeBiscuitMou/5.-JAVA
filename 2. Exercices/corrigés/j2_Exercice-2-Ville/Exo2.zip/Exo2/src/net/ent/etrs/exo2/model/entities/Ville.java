package net.ent.etrs.exo2.model.entities;

public class Ville {

    //ATTRIBUTS
    public String nom;
    public int nbHabitant;


    //METHODES

    /**
     * Affiche les informations de la ville.
     */
    public void afficherInfo(){

        System.out.println("Ville : " + nom);
        System.out.println("Nombre d'habitant :" +nbHabitant);
    }




}
