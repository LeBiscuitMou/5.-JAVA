package net.ent.etrs.bateau.model;

public class Bateau {
    public String nom;
    public Integer nbEquipage;
    public Float tonnage;
    public Boolean estPret;
    public TypeBateau classe;
}
