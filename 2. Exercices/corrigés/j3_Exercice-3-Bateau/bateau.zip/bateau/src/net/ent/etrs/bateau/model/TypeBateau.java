package net.ent.etrs.bateau.model;

public class TypeBateau {
    public String nom;
    public Integer longueur;
    public Float tonnageMax;
}
