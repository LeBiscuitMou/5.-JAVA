package net.ent.etrs.emploi.model.entities.references;

public enum JoursDeLaSemaine {
    LUNDI,
    MARDI,
    MERCREDI,
    JEUDI,
    VENDREDI
}
