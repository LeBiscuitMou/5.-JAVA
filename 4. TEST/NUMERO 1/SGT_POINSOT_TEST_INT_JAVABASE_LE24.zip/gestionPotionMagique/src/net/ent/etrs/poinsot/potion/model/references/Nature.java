package net.ent.etrs.poinsot.potion.model.references;

public enum Nature {
    LIQUIDE,
    PLANTE,
    ANIMAL,
    GAZEUX
}
