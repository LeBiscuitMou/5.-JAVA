package net.ent.etrs.gestionLeague.models.daos;

import net.ent.etrs.gestionLeague.models.entities.Challenge;

public interface IDaoChallenge extends BaseDao<Challenge> {
}
