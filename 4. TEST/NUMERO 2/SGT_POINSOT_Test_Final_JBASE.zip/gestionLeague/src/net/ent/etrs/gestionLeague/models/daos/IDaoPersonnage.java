package net.ent.etrs.gestionLeague.models.daos;

import net.ent.etrs.gestionLeague.models.entities.Personnage;

public interface IDaoPersonnage extends BaseDao<Personnage> {
}
