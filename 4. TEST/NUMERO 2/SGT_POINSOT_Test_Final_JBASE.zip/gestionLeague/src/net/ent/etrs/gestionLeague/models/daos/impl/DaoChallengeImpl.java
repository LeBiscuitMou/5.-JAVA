package net.ent.etrs.gestionLeague.models.daos.impl;

import net.ent.etrs.gestionLeague.models.daos.IDaoChallenge;
import net.ent.etrs.gestionLeague.models.daos.MemBaseDao;
import net.ent.etrs.gestionLeague.models.entities.Challenge;

public class DaoChallengeImpl extends MemBaseDao<Challenge> implements IDaoChallenge {
    protected DaoChallengeImpl() {
    }
}