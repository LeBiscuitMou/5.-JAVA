package net.ent.etrs.gestionLeague.models.entities.references;

public enum LabySpecialite {
    SLAYER,
    GLADIATOR,
    CHAMPION,
    ASSASSIN,
    SABOTEUR,
    TRICKSTER,
    JUGGERNAUT,
    BERSERKER,
    CHIEFTAIN,
    NECROMANCER,
    OCCULTIST,
    ELEMENTALIST,
    DEADEYE,
    RAIDER,
    PATHFINDER,
    INQUISITOR,
    HIEROPHANT,
    GUARDIAN,
    ASCENDANT;
}
